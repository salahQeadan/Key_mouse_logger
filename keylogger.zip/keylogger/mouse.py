from pynput.mouse import Listener


def on_move(x, y):
    with open("mouse.txt", "a") as f:
        f.write('Pointer moved to {0}\n'.format((str(x), str(y))))


def on_click(x, y, button, pressed):
    with open("mouse.txt", "a") as f:
        f.write('{0} at {1}\n'.format('Pressed' if pressed else 'Released',(str(x), str(y))))


def on_scroll(x, y, dx, dy):
    with open("mouse.txt", "a") as f:
        f.write('Scrolled {0} at {1}\n'.format('down' if dy < 0 else 'up',(str(x), str(y))))


with Listener( on_move=on_move,on_click=on_click,on_scroll=on_scroll) as l:
    l.join()


